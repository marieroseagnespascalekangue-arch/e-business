import os
import zipfile

EXCLURE = {'venv', '__pycache__', 'staticfiles', '.git', '.idea', '.vscode'}
sortie = 'boutique_artisanale.zip'
with zipfile.ZipFile(sortie, 'w', zipfile.ZIP_DEFLATED) as z:
    for racine, dossiers, fichiers in os.walk('.'):
        dossiers[:] = [d for d in dossiers if d not in EXCLURE]
        for nom in fichiers:
            if nom == sortie or nom.endswith('.pyc'):
                continue
            chemin = os.path.join(racine, nom)
            z.write(chemin, os.path.relpath(chemin, '.').replace(os.sep, '/'))
print('Archive créée :', sortie, round(os.path.getsize(sortie) / 1e6, 1), 'Mo')