from django.core.paginator import Paginator
from django.db import transaction
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST

from . import panier
from .forms import CommandeForm, PaiementForm
from .models import Categorie, Commande, LigneCommande, ProduitArtisanal, Vendeur


def _entier(valeur, defaut):
    try:
        return int(valeur)
    except (TypeError, ValueError):
        return defaut


def _grouper(produits):
    """Un seul produit affiché par modèle (les autres couleurs sont regroupées)."""
    vus = {}
    for p in produits:
        cle = (p.vendeur_id, p.modele) if p.modele else p.pk
        if cle in vus:
            vus[cle].nb_couleurs += 1
        else:
            p.nb_couleurs = 1
            vus[cle] = p
    return list(vus.values())


def catalogue(request):
    categorie_active = _entier(request.GET.get('categorie'), None)
    produits = (
        ProduitArtisanal.objects
        .filter(actif=True, stock__gt=0)
        .select_related('vendeur')
        .order_by('-cree_le')
    )
    if categorie_active:
        produits = produits.filter(categorie_id=categorie_active)
    page = Paginator(_grouper(produits), 12).get_page(request.GET.get('page'))
    return render(request, 'boutique/catalogue.html', {
        'page': page,
        'categories': Categorie.objects.all(),
        'categorie_active': categorie_active,
    })


def detail_produit(request, pk):
    produit = get_object_or_404(
        ProduitArtisanal.objects.select_related('vendeur', 'categorie'), pk=pk, actif=True
    )
    if produit.modele:
        variantes = list(
            ProduitArtisanal.objects
            .filter(actif=True, vendeur=produit.vendeur, modele=produit.modele)
            .order_by('couleur', 'pk')
        )
    else:
        variantes = []

    exclus = {produit.pk} | {v.pk for v in variantes}
    base = (
        ProduitArtisanal.objects
        .filter(actif=True, stock__gt=0)
        .select_related('vendeur')
        .exclude(pk__in=exclus)
        .order_by('-cree_le')
    )
    suggestions = []
    if produit.categorie_id:
        suggestions = _grouper(base.filter(categorie_id=produit.categorie_id))[:4]
    if len(suggestions) < 4:
        deja = {s.pk for s in suggestions}
        complement = [c for c in _grouper(base) if c.pk not in deja]
        suggestions += complement[:4 - len(suggestions)]

    return render(request, 'boutique/produit.html', {
        'produit': produit,
        'variantes': variantes,
        'suggestions': suggestions,
    })


def boutique_vendeur(request, pk):
    vendeur = get_object_or_404(Vendeur, pk=pk)
    produits = (
        ProduitArtisanal.objects
        .filter(vendeur=vendeur, actif=True, stock__gt=0)
        .order_by('-cree_le')
    )
    return render(request, 'boutique/vendeur.html', {
        'vendeur': vendeur,
        'produits': _grouper(produits),
    })


def voir_panier(request):
    lignes, total = panier.detail(request)
    return render(request, 'boutique/panier.html', {'lignes': lignes, 'total': total})


@require_POST
def ajouter_panier(request, pk):
    produit = get_object_or_404(ProduitArtisanal, pk=pk, actif=True)
    quantite = max(_entier(request.POST.get('quantite'), 1), 1)
    panier.ajouter(request, produit, quantite)
    return redirect('panier')


@require_POST
def modifier_panier(request, pk):
    produit = get_object_or_404(ProduitArtisanal, pk=pk, actif=True)
    quantite = _entier(request.POST.get('quantite'), 1)
    panier.definir(request, produit, quantite)
    return redirect('panier')


@require_POST
def retirer_panier(request, pk):
    panier.retirer(request, pk)
    return redirect('panier')


def commander(request):
    lignes, total = panier.detail(request)
    if not lignes:
        return redirect('panier')

    if request.method == 'POST':
        form = CommandeForm(request.POST)
        if form.is_valid():
            with transaction.atomic():
                commande = form.save(commit=False)
                commande.total = total
                commande.save()
                for l in lignes:
                    LigneCommande.objects.create(
                        commande=commande,
                        produit=l['produit'],
                        nom=l['produit'].nom_complet[:120],
                        prix_unitaire=l['produit'].prix_ttc,
                        quantite=l['quantite'],
                    )
            request.session['commande_id'] = commande.pk
            return redirect('paiement')
    else:
        form = CommandeForm()

    return render(request, 'boutique/commande.html',
                  {'form': form, 'lignes': lignes, 'total': total})


def paiement(request):
    commande = Commande.objects.filter(
        pk=request.session.get('commande_id'), statut='attente'
    ).first()
    if not commande:
        return redirect('catalogue')

    if request.method == 'POST':
        form = PaiementForm(request.POST)
        if form.is_valid():
            try:
                with transaction.atomic():
                    # Vérifie et décompte le stock au moment du paiement
                    for ligne in commande.lignes.all():
                        produit = ProduitArtisanal.objects.select_for_update().get(pk=ligne.produit_id)
                        if produit.stock < ligne.quantite:
                            raise ValueError(f'Stock insuffisant pour « {produit.nom_complet} ».')
                        produit.stock -= ligne.quantite
                        produit.save(update_fields=['stock'])
                    commande.statut = 'payee'
                    commande.operateur = form.cleaned_data['operateur']
                    commande.numero_paiement = form.cleaned_data['numero']
                    commande.save()
            except ValueError as erreur:
                form.add_error(None, str(erreur))
            else:
                request.session.pop('panier', None)
                return redirect('confirmation')
    else:
        form = PaiementForm()

    return render(request, 'boutique/paiement.html', {'form': form, 'commande': commande})


def confirmation(request):
    commande = Commande.objects.filter(
        pk=request.session.get('commande_id'), statut='payee'
    ).first()
    if not commande:
        return redirect('catalogue')
    return render(request, 'boutique/confirmation.html', {'commande': commande})