import os
import zipfile

EXCLURE = {'venv', '__pycache__', 'staticfiles', 'media', '.git', '.idea', '.vscode'}
IGNORER = {'db.sqlite3', 'boutique_artisanale.zip', 'mise_a_jour.zip'}
sortie = 'mise_a_jour.zip'
with zipfile.ZipFile(sortie, 'w', zipfile.ZIP_DEFLATED) as z:
    for racine, dossiers, fichiers in os.walk('.'):
        dossiers[:] = [d for d in dossiers if d not in EXCLURE]
        for nom in fichiers:
            if nom in IGNORER or nom.endswith('.pyc'):
                continue
            chemin = os.path.join(racine, nom)
            z.write(chemin, os.path.relpath(chemin, '.').replace(os.sep, '/'))
print('Archive créée :', sortie, round(os.path.getsize(sortie) / 1e6, 2), 'Mo')